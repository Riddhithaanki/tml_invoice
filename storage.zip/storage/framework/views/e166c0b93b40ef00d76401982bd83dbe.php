<?php $__env->startSection('content'); ?>
    <style>
        .welcome-banner {
            position: fixed;
            top: 20px;
            left: 50%;
            transform: translateX(-50%);
            background-color: #1a237e;
            color: white;
            padding: 15px 30px;
            border-radius: 10px;
            z-index: 1000;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            animation: fadeInOut 4s ease-in-out;
            text-align: center;
        }
    </style>

    <div class="container-fluid px-4 py-5">
        <div class="welcome-banner">
            Welcome, <?php echo e(Auth::user()->username); ?>! 
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\leadspro-main\resources\views/dashboard.blade.php ENDPATH**/ ?>