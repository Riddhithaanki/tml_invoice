<!DOCTYPE html>
<html lang="en" data-template="front-pages" data-assets-path="<?php echo e(asset('/')); ?>">

<head>
    <meta charset="UTF-8">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo $__env->yieldContent('title', 'Admin Panel'); ?></title>
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('img/favicon.ico')); ?>" />

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&ampdisplay=swap"
        rel="stylesheet" />

    <!-- Icons -->
    <link rel="stylesheet" href="<?php echo e(asset('vendor/fonts/materialdesignicons.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('vendor/fonts/flag-icons.css')); ?>" />

    <!-- Menu waves for no-customizer fix -->
    <link rel="stylesheet" href="<?php echo e(asset('vendor/libs/node-waves/node-waves.css')); ?>" />

    <!-- Core CSS -->
    

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    <link rel="stylesheet" href="<?php echo e(asset('vendor/css/rtl/core.css')); ?>" class="template-customizer-core-css" />
    <link rel="stylesheet" href="<?php echo e(asset('vendor/css/rtl/theme-default.css')); ?>" class="template-customizer-theme-css" />
    <link rel="stylesheet" href="<?php echo e(asset('css/demo.css')); ?>" class="template-customizer-theme-css" />

    <!-- Vendors CSS -->

    <link rel="stylesheet" href="<?php echo e(asset('vendor/libs/perfect-scrollbar/perfect-scrollbar.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('vendor/libs/typeahead-js/typeahead.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('vendor/libs/datatables-bs5/datatables.bootstrap5.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('vendor/libs/datatables-responsive-bs5/responsive.bootstrap5.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('vendor/libs/apex-charts/apex-charts.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('vendor/libs/swiper/swiper.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('vendor/libs/sweetalert2/sweetalert2.scss')); ?>" />
    <!-- Page CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('vendor/css/pages/cards-statistics.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('vendor/css/pages/cards-analytics.css')); ?>" />
    <!-- Add this in the <head> or before the closing </body> tag -->

    <!-- Add Leaflet.js CDN link in the <head> section -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.17.0/xlsx.full.min.js"></script>
    <!-- Helpers -->
    <!--! Template customizer & Theme config files MUST be included after core stylesheets and helpers.js in the <head> section -->
    <!--? Template customizer: To hide customizer set displayCustomizer value false in config.js.  -->
    <script src="<?php echo e(asset('vendor/js/template-customizer.js')); ?>"></script>
    <!--? Config:  Mandatory theme config file contain global vars & default theme options, Set your preferred theme option in this file.  -->
    
    <script src="<?php echo e(asset('vendor/js/helpers.js')); ?>"></script>
    <script src="<?php echo e(asset('js/config.js')); ?>"></script>

</head>

<body>
    <div class="layout-wrapper layout-content-navbar">
        <div class="layout-container">
            
            <?php echo $__env->make('layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="layout-page">
                
                <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="container" style="margin-top: 30px">
                    <div class="content-wrapper">
                        
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <script src="<?php echo e(asset('vendor/js/dropdown-hover.js')); ?>"></script>
    <script src="<?php echo e(asset('vendor/js/mega-dropdown.js')); ?>"></script>
</body>

<script src="<?php echo e(asset('vendor/libs/jquery/jquery.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/libs/popper/popper.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/bootstrap.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/libs/node-waves/node-waves.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/libs/perfect-scrollbar/perfect-scrollbar.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/libs/hammer/hammer.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/libs/i18n/i18n.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/libs/typeahead-js/typeahead.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/js/menu.js')); ?>"></script>

<!-- endbuild -->

<!-- Vendors JS -->
<script src="<?php echo e(asset('vendor/libs/datatables-bs5/datatables-bootstrap5.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/libs/apex-charts/apexcharts.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/libs/swiper/swiper.js')); ?>"></script>
<script src="<?php echo e(asset('vendor/libs/sweetalert2/sweetalert2.js')); ?>"></script>
<!-- Main JS -->
<script src="<?php echo e(asset('js/main.js')); ?>"></script>



<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

<script>
    $(document).ready(function () {
        <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                toastr.error("<?php echo e($error); ?>");
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

        <?php if(session('success')): ?>
            toastr.success("<?php echo e(session('success')); ?>");
        <?php endif; ?>

        <?php if(session('error')): ?>
            toastr.error("<?php echo e(session('error')); ?>");
        <?php endif; ?>
    });
</script>

</html><?php /**PATH C:\xampp\htdocs\leadspro-main\resources\views/layouts/main.blade.php ENDPATH**/ ?>